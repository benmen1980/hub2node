module.exports = {
    getCredentails: function getCredentails(){
        let configuration = {
            appname: 'demo',
            username: 'API',
            password: '1234567',
            url: 'https://prioritydev.simplyct.co.il',
            tabulaini: 'tabula.ini',
            language: 2,
            profile: {
                company: 'demo',
            },
            devicename: 'Roy',
            appid: '*****',
            appkey: '*****'

        };
        return configuration;
    }
}